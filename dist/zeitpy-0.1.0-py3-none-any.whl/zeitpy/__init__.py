# zeitpy\main\__init__.py

from .core import Zeit